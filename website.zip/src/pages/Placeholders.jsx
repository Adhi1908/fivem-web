import React from "react";

export const About = () => <div className="container mx-auto py-20 text-white"><h1>About Us</h1><p>Placeholder for About page</p></div>;
export const Features = () => <div className="container mx-auto py-20 text-white"><h1>Features</h1><p>Placeholder for Features page</p></div>;
export const Rules = () => <div className="container mx-auto py-20 text-white"><h1>Rules</h1><p>Placeholder for Rules page</p></div>;
export const Store = () => <div className="container mx-auto py-20 text-white"><h1>Store</h1><p>Placeholder for Store page</p></div>;
export const Apply = () => <div className="container mx-auto py-20 text-white"><h1>Apply</h1><p>Placeholder for Apply page</p></div>;
export const Contact = () => <div className="container mx-auto py-20 text-white"><h1>Contact</h1><p>Placeholder for Contact page</p></div>;
